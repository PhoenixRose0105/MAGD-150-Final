let song;

let img;

var img2;
var img3;

var Frog, Herbs, Monster, Produce, Witch, Cauldron;

//oval potion
var x = 540;
var y = 110;
var w = 30;
var h = 70;
var radius = 20;

function preload(){
  img = loadImage('images/Door.jpg');
   
  img3 = loadImage('images/Window.PNG');
  
  Witch = createImg('gifs/Witch.gif','');
  
  Cauldron = createImg('gifs/Cauldron.gif', '');
  
  Herbs = createImg('gifs/Herbs.gif', '');
  
  Monster = createImg('gifs/Monster.gif','');
  
 Produce = createImg('gifs/Produce.gif','');
  
  Frog = createImg('gifs/Frog.gif','');
  
 img2 = loadImage('images/Wand.jpg');
}

function setup() {
  createCanvas(700, 400); 
  
  //background music
  song = createAudio('audio/Music.mp3');
  song.autoplay(true);
  song.volume(0.2);
}

function draw() {
  background(108, 93, 81);
  strokeWeight(6);

  //carpet
  {push();
  fill(87, 47, 59);
  quad(79, 380, 152,300, 622,300, 550, 380);
  pop();}
  
  //right counter
  {push();
  fill(37, 23, 30);
  square(620,190,80);
  rect(360,150,200,80);
  fill(37, 23, 30);
  quad(619,270,620,190,562,151,560,230);
  fill(0);
  beginShape();
  vertex(360,150);
  vertex(360, 135);
  vertex(620, 135);
  vertex(700, 190);
  vertex(620,190);
  vertex(562,150);
  endShape();
  pop();}
  
  //wall outline 
  {  line(620,135,620,5);
  line(360,230,80,230);}
  
  //shelfs
  {push();
  fill(0);
  stroke(0);
  line(230,100,340,100);
  line(230,70,340,70);
  line(230,40,340,40);
  pop();}
  
  //potions
  {strokeWeight(1.5);
  
  push();
  fill(200);
  rect(245,19,15,20);
  pop();
  
  push();
  fill(255,127,140);
  rect(268,24,20,15);
  pop();
  
  push();
  fill(75);
  rect(305,14,23,25);
  pop();
  
  push();
  fill(255,206,108);
  rect(252,54,30,15);
  pop();
  
  push();
  fill(139,255,121);
  rect(293,49,15,20);
  pop();
  
  push();
  fill(160);
  rect(240,81,23,18);
  pop();
  
  push();
  fill(108,195,255);
  rect(285,84,40,15);
  pop();
  
  push();
  fill(225,141,78);
  rect(250,15,5,5);
  
  rect(276,20,5,5);
  
  rect(310,10,5,5);
  
  rect(270,50,5,5);
  
  rect(298,45,5,5);
  
  rect(249,77,5,5);
  
  rect(290,80,5,5);
  pop();}
  
  //counter potions
  {ellipse(x,y,w,h);
  
  push()
  strokeWeight(1);
  fill(225,141,78);
  rect(532,68,16,10);
  pop();}
  
  //hangers
  {push();
  stroke(0);
  fill(0);
  ellipse(250,120,10,10)
  ellipse(285,120,10,10);
  ellipse(320,120,10,10);
  pop();}
  
  //left counter
  {push();
  fill(37, 23, 30);
  quad(0,365,80,260,80,151,0,255);
  fill(0);
  beginShape();
  vertex(0,255);
  vertex(77, 150);
  vertex(0, 150);
  endShape();
  pop();}
  
  //menu
  {push();
  fill(117, 133, 101);
  rect(20,20,60,100);
  pop();}
  
  //window
  image(img3,400,30);
  
  //witch
  Witch.position(350,60);
  
  //cauldron
  Cauldron.position(265,218);
  
  //frog
  Frog.position(25,310);
  
  //monster
  Monster.position(5,130);
  
  //door
  image(img,92,13,125,220);
  
  //produce
  {push();
  strokeWeight(1);
  fill(255);
  rect(527,230,23,20);
  pop();
  
  Produce.position(465,155);}
  
  //herbs
  Herbs.position(600,90);

  //wand cursor
  image(img2,mouseX,mouseY,15,50);
}

function mousePressed(){
   var d = dist(mouseX,mouseY,x,y);
    if (d < radius){
      fill(189,120,224);
    } else {
      fill(255);
    }

  ellipse(x,y,radius,radius);
}
